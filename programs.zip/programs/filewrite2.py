

# traditional approach
fobj  = open("demo.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()



# pythonic way
# context manager
# context manager begins with the keyword 'with'
#Advantage :  file will be closed automatically
with open("demo.txt","w")  as fobj:
    fobj.write("python programming\n")
    fobj.write("scala programming\n")

