# file open
#case 1: If the file is not existing, file will be created first
#case 2: If the file is already existing, it overwrites the existing content

fobj  = open("languagesdemo.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")

# close file
fobj.close()


# file open
fobj  = open("languagesdemo.txt","a")
for val in range(1,11):
    fobj.write(str(val) + "\n")
# close file
fobj.close()


#fobj  = open("D:/accenture/languagesdemo.txt","w")  #or
#fobj  = open(r"D:\accenture\languagesdemo.txt","w") #or   # raw format
fobj  = open("D:\\accenture\\languagesdemo.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
# close file
fobj.close()