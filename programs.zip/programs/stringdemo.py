
print(10,20,30)

print("unix","java")

# slicing
# string[start:stop:step]
name = "python programming"
print(name)
print(name[0:4])
print(name[4:9])
print(name[0:17])
print(name[:])
print(name[::])
print(name[0:4:2])
print(name[0:17:2])
print(name[1:17:2])
print(name[0:17:3])
print(name[-1])
print(name[-2])
print(name[::2])
print(name[::-1])  #gnimmargorp nohtyp
print(name[::-2])  #gimropnhy


# string methods
name = "python programming"
print(name.isupper())
print(name.islower())
print(name.isalpha())

print(name.split(" "))

print(name.replace("python","scala"))
print(name.split("p"))
aname = " python"
print(len(aname))
print(aname.strip())  # remove whitespaces at both the ends
print(len(aname.strip()))
print(len(aname.lstrip()))
print(len(aname.rstrip()))

# convert list to string
alist  = ['unix',"java","oracle"]
print("-".join(alist))   #unix-java-oracle

# template
bname = "I love {} and {}"
print(bname.format("unix","java"))
print(bname.format("oracle","tcs"))
print(bname.format(1,2))

print(name.encode('utf-8'))
print(name.encode('utf-16'))
print(name.encode('utf-32'))


print(name.count('p'))  #2

print(name.isupper())
print(name.islower())
print(name.isalpha())


cname = "java"
if cname.isupper():
    print("String is upper")
else:
    print("String is lower")


if cname.startswith('j'):
    print("java programming")
else:
    print("python programming")


cname = "java"
if cname.isupper():
    print("String is upper")
    print("Inside if")
    print("Still inside if")
else:
    print("String is lower")
    print("Inside else")
    print("Still inside else")
    



name = "python"

for char in name:
    print(char)


























