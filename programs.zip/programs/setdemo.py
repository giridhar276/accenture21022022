aset  = {30,10,20,30,20,30,10}
print(aset)
bset = {30,30,30,30,40,50,50,50}
print(bset)

print("**** union ****")
print(aset.union(bset))
print('*** Intersection***')
print(aset.intersection(bset))
print('**** difference ****')
print(aset.difference(bset))

print(aset.issuperset(bset))

# if cond
if 10 in aset:
    print('exists...!!!')
else:
    print("value doesnt exist")

# for loop
aset  = {30,10,20,30,20,30,10}
for val in aset:
    print(val)
    
    
    