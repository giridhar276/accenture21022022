import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        #if 'python' in line or 'pyttthon' in line:
        if re.search("^python",line):
            print(line)
            
import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        #if 'python' in line or 'pyttthon' in line:
        if re.search("^python$",line):
            print(line)       
            
import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        #if 'python' in line or 'pyttthon' in line:
        if re.search("pyt{1}hon",line):
            print(line)
            
import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        #if 'python' in line or 'pyttthon' in line:
        if re.search("python|unix",line):
            print(line)            