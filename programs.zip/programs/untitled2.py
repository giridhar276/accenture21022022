
print(10,20,30)

print("unix","java")

# slicing
# string[start:stop:step]
name = "python programming"

print(name[0:4])
print(name[4:9])
print(name[0:17])
print(name[:])
print(name[::])
print(name[0:4:2])
print(name[0:17:2])
print(name[1:17:2])
print(name[0:17:3])
print(name[-1])
print(name[-2])
print(name[::2])
print(name[::-1])
print(name[::-2])