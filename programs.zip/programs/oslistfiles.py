


import os

#print(os.listdir())
# listing all the files


for file in os.listdir():
    print(file)
    
    
    
for file in os.listdir("D:\\"):
    print(file)    