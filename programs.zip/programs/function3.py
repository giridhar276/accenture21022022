


## keyword  parameters


def display(b,a):
    print(a,b)


display(a=10,b=20)




print(10,20)
print(10,20,sep="  ")
print(10,20,sep= ":",end="\n\n")
print(10,20,end= "\n\n", sep=":")