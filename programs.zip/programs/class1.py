


class Employee:
    def displayName(self):
        print("Employee name is","Rita")
        
# object initialization
emp1 = Employee()
emp1.displayName()