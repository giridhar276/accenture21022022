import os
import pymysql
import csv
try:
    #step1 : establish the connection
    count = 0
    db = pymysql.connect(host ='127.0.0.1',port=3306 ,user='root',password='india@123',database='accenture')
    cursor = db.cursor()
    if db:
        filename = "realestate.csv"
        if os.path.isfile(filename) and os.path.getsize(filename) > 0:
            with open(filename,"r") as fobj:
                reader = csv.reader(fobj)
                for line in reader:
                    #step2: create cursor
                    street = line[0]
                    city = line[1]
                    #step3 : define query
                    query = "insert into realestate values('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')"

                    output = query.format(street,city)
                    #step4 : execute the query
                    cursor.execute(output)
                    count = count + 1
        print(count ,"records inserted")
        db.commit()
        #close the connection
        db.close()
    else:
        print("file not found")        

except pymysql.err.OperationalError as err:
    print(err)
    print('Invalid host or port or user or password .... pl check')
except Exception as err:
    print(err)
