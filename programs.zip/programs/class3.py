

class Employee:
    def __init__(self,name):
        self.name = name
        #localname = global
    def displayName(self):
        print(self.name)
        
# object initialization
# constructor is invoked automatically when object is created
# In python , constructor is defined in __init__
emp1 = Employee('Ram')
emp1.displayName()


emp2 = Employee('Rita')
emp2.displayName()


emp3 = Employee('Gita')
emp3.displayName()

