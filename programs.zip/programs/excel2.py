import pymysql
import csv
import time
import os
from openpyxl import Workbook

try:
    wb = Workbook()
    ws = wb.active
    #step1 : establish the connection
    db = pymysql.connect(host ='127.0.0.1',port=3306 ,user='root',password='india@123',database='accenture')
    if db:
        #step2: create cursor
        cursor = db.cursor()
        #step3 : define query
        #filename = "output1.csv"
        filename = time.strftime("%d_%b_%Y.xlsx")
        if os.path.exists(filename):
            #os.unlink(filename)
            os.rename(filename,filename + ".bak")
        query = "select * from realestateinfo"
        with open(filename,"w") as fw:
            #step4 : execute the query
            cursor.execute(query)            
            #step5: fetch the data
            for record in cursor.fetchall():
                #print(record)
                #fw.write(",".join(record) +"\n")
                print(record)
                ws.append(record)
    
    wb.save(filename)
    #close the connection
    db.close()
        

except pymysql.err.OperationalError as err:
    print(err)
    print('Invalid host or port or user or password .... pl check')
except Exception as err:
    print(err)
