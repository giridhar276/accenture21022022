
class Employee:
    def getName(self,name):
        self.name = name
        #localname = global
    def displayName(self):
        print(self.name)
        
# object initialization
emp1 = Employee()
emp1.getName('Ram')
emp1.displayName()


emp2 = Employee()
emp2.getName('Diksha')
emp2.displayName()


emp3 = Employee()
emp3.getName('Diksha')
emp3.displayName()