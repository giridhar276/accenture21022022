# regular function
def display(a,b):
    c = a + b

# calling function
display(10,20)

## function to return the string to uppercase
def display(x):
    return x.upper()

# calling function
display('python')

#lambda : inline function in java
# lambda is the replacement of single liner function
#the function body will be replaced in calling function
#syntax
#functioname = lambda variables : expression
display = lambda x,y : x+y
# calling function
print(display(10,20))

name = "python"
toupper = lambda x: x.upper()
print(toupper(name))

display = lambda *args : sum(args)
# calling function
print(display(10,20,30,30,40))









alist = [10,20,30,40,50]
#[15,25,35,45,55]

blist = []
for val in alist:
    blist.append(val + 5)
print(blist)


alist = ["unix","c","cpp","oracle"]
#[4,1,3,6]
blist = []
for val in alist:
    blist.append( len(val))
print(blist)


#map()
alist = [10,20,30,40,50]
def increment(x):
    return x+5
#map(functionname,iterable)
print(list(map(increment,alist)))

# using lambda
alist = [10,20,30,40,50]
#map(functionname,iterable)
print(list(map(lambda x:x+5,alist)))

# using list comprehension
alist = [10,20,30,40,50]
blist = [ x+5   for x in alist]
print(blist)


#alist = [1,2,3,4,5,6,7,8]
#even numbers : [2,4,6,8]

alist = [1,2,3,4,5,6,7,8]
print(list(filter(lambda x: x%2,alist)))
print(list(filter(lambda x: x%2 ==1,alist)))

print(list(filter(lambda x: x%2 ==0,alist)))

alist = ["unix","java","ruby","oracle","scala"]
#['unix','java','ruby]
print(list(filter(lambda x: len(x) ==4 ,alist)))

blist = []
for val in alist:
    if len(val)  ==4 :
        blist.append(val)
print(blist)


# reduce
alist = ["python","ruby","hadoop","kafka","scala"]
#pythonrubyhadoopkafkascala


import functools
alist = ["python","ruby","hadoop","kafka","scala"]
print(functools.reduce(lambda x,y: x+y ,alist))



#list comprehension

#  [ expression  for loop   ]
squares = [  x*x   for x in range(1,10)]
print(squares)


# convert string to upper
name = "I stay in Hyderabad"
output = [ s.upper()  for s in name]
print(output)


#remove commas from the end of the string
alist = ["python,","is,","general,","purpose,","programming,","language,"]
#['python','is','general','purpose','programming','language']
output = [  word.strip(',')  for word in alist]
print(output)


strinput = "python programming"
name="aeiou"
# output
#['*', '*', '*', '*', 'o', '*', '*', '*', '*', 'o', '*', '*', 'a', '*', '*', 'i', '*', '*']



output = [ x if x in name else '*'   for x in strinput]
print(output)


output = [ x  for x in range(1,10)  if x%2 == 0]
print(output)



#############################
# dictionary comprehension
############################
alist = [1,2,3,4]

#output 
#{1:1,2:4,3:9,4:16}
output = { x: x*x     for x in alist}
print(output)
#2
info = ["I","love","python","programming"]
#{"I":1 ,"love":4 ,"python":6 "programming":12 }
output = {  char:len(char)     for char in info}
print(output)

####################################
# set comprehension
###################################
output = {x for x in range(1,11)}
print(output)

output = { x    for x in range(1,100) if x %2 == 0}
print(output)

# work on this task
x = [10,20,30]
y = [30,40,50]
#output [40,50,60,50,60,70,60,70,80]
output =     [ first + second  for first in x   for second in y ]
print(output)

















