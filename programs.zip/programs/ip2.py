
'''
Write a Python program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
192.168.1.1
192.168.1.2
192.168.1.3
..
..
192.168.1.10
'''

fixed = "192.168."
for val in [0,1]:
    iip = fixed + str(val)
    for ival in range(1,11):
        print(iip + "." + str(ival))