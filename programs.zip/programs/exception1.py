#method3        
try:
    filename = input('Enter any filename :')   
    with open(filename,"r")as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except Exception as err:
    print(err)
    

# customized messages
#method3        
try:
    filename = input('Enter any filename :')   
    with open(filename,"r")as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except FileNotFoundError as error:
    print('File not found')
    print(error)
except TypeError as err:
    print("Invalid operation")
    print(err)
except (ValueError,KeyError) as err:
    print(err)
except Exception as err:
    print("Some error found")