



# fobj can be called as file cursor or pointer or reference
with open("info.txt","r") as fobj:
    for line in fobj:
        # removing whitespaces if any
        line = line.strip()
        output = line.split(",")
        print(output[0])
    
    
    
import csv
# fobj can be called as file cursor or pointer or reference
with open("info.txt","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line[0])
    