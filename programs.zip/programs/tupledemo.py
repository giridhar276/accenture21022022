
alist = [56,46,43,87,6]
alist[0] = 1000
print(alist)



atup = (87,12,45,43)
#atup[0] = 2000
print('after replacing' , atup)


# typecasting
#convert tuple -->list
alist = list(atup)
# make your changes
alist.append(31)
#recoverting back to tuple
atup = tuple(alist)
print(atup)


output = (45,3,56,43)


name = "python programming"
name[0] = "z"
print(name)
