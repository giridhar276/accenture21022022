


#method3        
citylist =[]     
with open("realestate.csv","r")as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
        
        




#method3        
citylist =[]     
with open("realestate.csv","r")as fobj:
    with open("output.csv", "w") as fw:
        for line in fobj:
            line = line.strip()
            line = line.replace('SACRAMENTO','HYDERABAD')
            #print(line)
            fw.write(line + "\n")        