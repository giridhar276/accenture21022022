print(10,20)

print(list(range(1,10)))

alist = [10,20,30,40]
print(type(alist))

print(max(alist))

print(min(alist))

print(sum(alist))

name = 'python'
print(type(name))

val = input()
print(val)

val = input('Enter any value :')
print(val)
print(type(val))

name = input("Enter any name :")
print(name)
print(type(name))

aset = {10,20,20}
print(type(aset))



name = "python"
print(isinstance(name,str))
print(isinstance(name,list))
print(isinstance(name,dict))

if isinstance(name,str) :
    print("Yes.. it is string")
else:
    print("Some other object")







