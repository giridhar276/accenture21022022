book = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book)


print(book["chap10"])
# add new key-value pair
#dict[key] = value
book["chap4"] = 40

print(book)
#display KEYS
print(book.keys())

# display only value
print(book.values())

# display key:value
print(book.items())

book = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book['chap1'])  #10
print(book["chap8"])

# method1
if 'chap8' in book:
    print(book['chap8'])
else:
    print("key doesn't exist")

#method2
# key is existing .. return the value
print(book.get("chap8"))
# key is not existing.. return None
print(book.get("chap1"))

book1 = {"chap5":50 ,"chap6":60}
book.update(book1)   # all the key:values of book1 will be added to book
book1.update(book)




### display keys
for key in book:
    print(key)
    
for key in book.keys():
    print(key)    



# display values
for value in book.values():
    print(value)
    
    
    
# display key:value
for key,value in book.items():
    print(key, value)
    
    
    
    




