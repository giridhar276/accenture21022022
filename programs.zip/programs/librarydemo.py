
import math
print(math.log(2))
print(math.tan(1))
print(math.floor(34.2))


# using alias
import math as m
print(m.tan(2))
print(m.ceil(43.6))


#accessing required methods ONLY
# . is not required here
from math import tan,cos
print(tan(1))
print(cos(1))
