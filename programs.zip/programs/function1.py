
# fixed arguments
def display(a,b):
    print(a,b)

# calling function
display(10,20,30)




def display(a,b,c):
    print(a,b,c)

# calling function
display(10,20)