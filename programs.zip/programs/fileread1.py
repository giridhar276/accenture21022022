
# fobj can be called as file cursor or pointer or reference
with open("info.txt","r") as fobj:
    for line in fobj:
        # removing whitespaces if any
        line = line.strip()
        print(line)
    
    

## using readlines()
with open('info.txt','r') as fobj:
    print(fobj.readlines())
    

## using readlines()  - using loop
with open('info.txt','r') as fobj:
    for line in fobj.readlines()  :
        print(line)
        

# using read()
with open('info.txt','r') as fobj:
    ##----------->  output will be in the string format
    print(fobj.read())   
    

with open('info.txt','r') as fobj:
    ##----------->  output will be in the string format
    print(fobj.read(4))     