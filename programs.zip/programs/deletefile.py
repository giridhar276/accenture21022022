


import os

filename = "realestate.csv"

print(os.getcwd())
if filename in os.listdir():
    os.unlink(filename)
else:
    print(filename, "doesn't exist")
    
    
    
import os
existing = os.getcwd()
filename = "output.txt"
os.chdir("D:\\")
print(os.getcwd())
if filename in os.listdir():
    os.unlink(filename)
else:
    print(filename, "doesn't exist")   
os.chdir(existing)
    
    



