

from google.cloud import bigquery
import os

credentials_path = 'credentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path
client = bigquery.Client()



def table_exists(table_id):

    # [START bigquery_table_exists]
    from google.cloud import bigquery
    from google.cloud.exceptions import NotFound

    client = bigquery.Client()

    # TODO(developer): Set table_id to the ID of the table to determine existence.
    # table_id = "your-project.your_dataset.your_table"

    try:
        client.get_table(table_id)  # Make an API request.
        print("Table {} already exists.".format(table_id))
    except NotFound:
        print("Table {} is not found.".format(table_id))
    # [END bigquery_table_exists]
    
    
table_exists('testing-341617.employeeinfo.realestate3')    