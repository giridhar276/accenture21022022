

#
import requests
import json


response = requests.get('https://api.github.com/')

print(response.status_code)

if response.status_code == 200 :
    #print(response.text)
    # convert string object to dictionary object
    data= json.loads(response.text)
    #print(type(data))
    for key,value in data.items():
        print(value)
    

else:
    print('Invalid operation')

