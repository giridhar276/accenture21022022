

from google.cloud import bigquery
import os

#your filename
credentials = "giritest-342407-0ae9e0aecf48.json"

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials

client = bigquery.Client()
print(client)
#                                      project       datasetname  tablename
query = client.query("select * from giritest-342407.giridataset.realestate")

results = query.result()

for record in results :
    print(record)
    print("--------------")
    
    
from google.cloud import bigquery
import os

#your filename
credentials = "giritest-342407-0ae9e0aecf48.json"

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials

client = bigquery.Client()
print(client)

query = client.query("select * from giritest-342407.giridataset.realestate")

results = query.result()

for record in results :
    print(record)
    print("--------------")
    