
from google.cloud import bigquery
import os

credentials_path = 'giritest-342407-0ae9e0aecf48.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path
client = bigquery.Client()


def table_insert_rows(table_id):

    # TODO(developer): Set table_id to the ID of table to append to.
    # table_id = "your-project.your_dataset.your_table"

    rows_to_insert = [
        {u"full_name": u"Phred Phlyntstone", u"age": 32},
        {u"full_name": u"Wylma Phlyntstone", u"age": 29},
    ]

    errors = client.insert_rows_json(table_id, rows_to_insert)  # Make an API request.
    if errors == []:
        print("New rows have been added.")
    else:
        print("Encountered errors while inserting rows: {}".format(errors))
    # [END bigquery_table_insert_rows]


table_insert_rows('giritest-342407.giridataset.realestate')