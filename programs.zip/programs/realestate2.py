
import csv

#method3        
citylist =[]     
with open("realestate.csv","r")as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        citylist.append(city)
    # display the data
    for city in set(citylist):
        print(city.ljust(16) , citylist.count(city),"times")

                