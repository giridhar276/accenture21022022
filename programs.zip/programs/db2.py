

import pymysql
try:
    #step1 : establish the connection
    db = pymysql.connect(host ='127.0.0.1',port=3306 ,user='root',password='india@123',database='accenture')
    if db:
        #step2: create cursor
        cursor = db.cursor()
        #step3 : define query
        query = "insert into realestate values('{}','{}')"
        
        query = query.format('Hitechcity','Hyderabad')
        #step4 : execute the query
        cursor.execute(query)
        
    db.commit()
    #close the connection
    db.close()
        

except pymysql.err.OperationalError as err:
    print(err)
    print('Invalid host or port or user or password .... pl check')
except Exception as err:
    print(err)
