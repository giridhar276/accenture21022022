# method1
import csv
cityset = set()
with open("realestate.csv","r")as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        cityset.add(city)
    # display the data
    for city in cityset:
        print(city)
    print("Total no. of cities :", len(cityset))
    
# method2
citydict = dict()
with open("realestate.csv","r")as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        #converting each city to the dict key
        citydict[city] = 1
    # display the data
    for city in citydict:
        print(city)
    print("Total no. of cities :", len(citydict))
    
#method3        
citylist =[]     
with open("realestate.csv","r")as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        citylist.append(city)
    # display the data
    for city in set(citylist):
        print(city)
    print("Total no. of cities :", len(citylist))
                
        
        
        
citylist =[]     
with open("realestate.csv","r")as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        if city not in citylist:
            citylist.append(city)
    # display the data
    for city in citylist:
        print(city)
    print("Total no. of cities :", len(citylist))
                
        