

#1 22 333 4444 55555 666666 7777777 88888888 999999999


for val in range(1,10):
    print(str(val) * val , end = " ")
    
    
