alist = [10,45,56,43,23,65,76,12,12,12]
alist.append(98)
print('After appending :', alist)
alist.append(72)
print('After appending :', alist)

alist.extend([13,14,35])
print('After extending :', alist)

#list.insert(index,value)
#list.insert(where to insert, what to insert)
alist.insert(1,1000)
print('After inserting:', alist)

# using index
alist.pop(2)  # 2 is the index
print('After pop :', alist)

alist.remove(76)
print("After remove :", alist)

alist.remove(76)
print("After remove :", alist)


if 76 in alist:
    alist.remove(76)
else:
    print('element not found')
print(alist.count(12))

# sort()
alist.sort()
print("After sorting", alist)
# reverse order
alist.sort(reverse = True)
print("After sorting", alist)

alist = [12,43,45,32,5]
alist.reverse()
print(alist)



# index is not used
alist = [56,34,56,76,43]
for val in alist:
    print(val)
    
# c style of coding
for val in range(0,len(alist)):
    print(alist[val])
    
    
    
    
    
    
    
    
    
    
    

