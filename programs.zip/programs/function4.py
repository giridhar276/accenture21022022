#################################
# fixed arguments
def display(a,b):
    print(a,b)

# calling function
display(10,20)

#############################################
# default args###############################
def display(a = 0,b = 0,c = 0):
    print(a,b,c)

# calling function
display()
display(10)
display(10,20)
display(10,20,30)

#############################################
# keyword args################################
def display(b,a):
    print(a,b)
display(a=10,b=20)

#############################################
#variable length arguments
#If any object is prefixed with * ... it becomes tuple
def display(*arg):
    print(arg)
display(10,20,30,40,12,23,34,45,56,43,32,21,45,32)


## If any object is prefixed with ** .. it become dictionary
def display(**kargs):
    print(kargs)

display(chap1 = 10 , chap2 = 20)
